export default function SummaryCard({ title, amount, detail, currency = true }) {
  const value = currency ? `Rs. ${Number(amount || 0).toLocaleString("en-IN")}` : amount;

  return (
    <div className="card metric-card">
      <h3>{title}</h3>
      <strong>{value}</strong>
      {detail && <p>{detail}</p>}
    </div>
  );
}
