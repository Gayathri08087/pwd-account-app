import { useState } from "react";
import { NavLink } from "react-router-dom";

const navGroups = [
  {
    title: "Overview",
    links: [{ to: "/", label: "Dashboard" }],
  },
  {
    title: "Accounts",
    links: [
      { to: "/income", label: "Income" },
      { to: "/work", label: "Work Management" },
      { to: "/home", label: "Home Expenses" },
      { to: "/workers", label: "Workers" },
      { to: "/salary", label: "Salary Report" },
    ],
  },
  {
    title: "Reports",
    links: [
      { to: "/balance", label: "Balance Sheet" },
      { to: "/monthly", label: "Monthly Report" },
      { to: "/pending", label: "Pending Payments" },
    ],
  },
];

export default function Sidebar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <aside className="sidebar">
      <div className="sidebar-top">
        <div className="brand">
          <span className="brand-mark">P</span>
          <div>
            <h1>PWD Manager</h1>
            <p>Accounts dashboard</p>
          </div>
        </div>

        <button
          type="button"
          className="menu-toggle"
          aria-expanded={isMenuOpen}
          aria-label="Toggle navigation menu"
          onClick={() => setIsMenuOpen((current) => !current)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>

      <nav className={`nav-groups ${isMenuOpen ? "open" : ""}`} aria-label="Main navigation">
        {navGroups.map((group) => (
          <section className="nav-group" key={group.title}>
            <h2>{group.title}</h2>
            {group.links.map((link) => (
              <NavLink
                end={link.to === "/"}
                key={link.to}
                to={link.to}
                className={({ isActive }) => (isActive ? "active" : undefined)}
                onClick={() => setIsMenuOpen(false)}
              >
                {link.label}
              </NavLink>
            ))}
          </section>
        ))}
      </nav>
    </aside>
  );
}
