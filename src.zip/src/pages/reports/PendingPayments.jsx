import useStore from "../../store/useStore";
import Table from "../../components/Table";
import { STORAGE_KEYS } from "../../utils/constants";
import { formatCurrency } from "../../utils/dataFormat";

const displayDate = (value) => {
  if (!value) return "-";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleDateString("en-IN");
};

export default function PendingPayment() {
  const [records] = useStore(STORAGE_KEYS.WORK_RECORDS, []);

  const pending = records
    .filter((record) => Number(record.remainingAmount || 0) > 0)
    .map((record) => ({
      project: record.project,
      personName: record.personName,
      material: record.material,
      totalAmount: formatCurrency(record.totalAmount),
      paidAmount: formatCurrency(record.paidAmount),
      remainingAmount: formatCurrency(record.remainingAmount),
      date: displayDate(record.date),
    }));

  return (
    <div className="page">
      <header className="page-header">
        <div>
          <p className="eyebrow">Reports</p>
          <h1>Pending Payments</h1>
        </div>
      </header>

      <Table
        columns={["project", "personName", "material", "totalAmount", "paidAmount", "remainingAmount", "date"]}
        data={pending}
        emptyMessage="All work records are fully paid."
      />
    </div>
  );
}
