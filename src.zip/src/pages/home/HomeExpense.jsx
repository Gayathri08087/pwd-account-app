import { useState } from "react";
import useStore from "../../store/useStore";
import { formatCurrency } from "../../utils/dataFormat";

const initialForm = {
  item: "",
  amount: "",
};

export default function HomeExpense() {
  const [expenses, setExpenses] = useStore("home", []);
  const [form, setForm] = useState(initialForm);

  const save = (event) => {
    event.preventDefault();
    if (!form.item.trim() || !form.amount) return;

    setExpenses([
      ...expenses,
      {
        item: form.item.trim(),
        amount: Number(form.amount),
      },
    ]);
    setForm(initialForm);
  };

  return (
    <div className="page">
      <header className="page-header">
        <div>
          <p className="eyebrow">Accounts</p>
          <h1>Home Expense</h1>
        </div>
      </header>

      <form className="form-panel" onSubmit={save}>
        <label className="field">
          <span>Expense Item</span>
          <input
            placeholder="Electricity bill"
            value={form.item}
            onChange={(event) => setForm({ ...form, item: event.target.value })}
          />
        </label>

        <label className="field">
          <span>Amount</span>
          <input
            min="0"
            placeholder="3000"
            type="number"
            value={form.amount}
            onChange={(event) => setForm({ ...form, amount: event.target.value })}
          />
        </label>

        <button type="submit">Save Expense</button>
      </form>

      <section className="record-grid">
        {expenses.length === 0 ? (
          <p className="empty-state">No home expenses have been saved yet.</p>
        ) : (
          expenses.map((expense, index) => (
            <article key={`${expense.item}-${index}`} className="card record-card">
              <span>Home</span>
              <h2>{expense.item}</h2>
              <p>{formatCurrency(expense.amount)}</p>
            </article>
          ))
        )}
      </section>
    </div>
  );
}
