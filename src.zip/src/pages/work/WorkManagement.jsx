import { useMemo, useState } from "react";
import Table from "../../components/Table";
import useStore from "../../store/useStore";
import { STORAGE_KEYS } from "../../utils/constants";
import { calculateTotal, formatCurrency } from "../../utils/dataFormat";

const todayInputDate = () => new Date().toISOString().slice(0, 10);

const initialRecord = {
  project: "",
  date: todayInputDate(),
  personName: "",
  material: "",
  quantity: "",
  totalAmount: "",
  paidAmount: "",
  paidDate: "",
};

const displayDate = (value) => {
  if (!value) return "-";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleDateString("en-IN");
};

const normalizeRecord = (record) => {
  const totalAmount = Number(record.totalAmount || 0);
  const paidAmount = Math.min(Number(record.paidAmount || 0), totalAmount);
  const remainingAmount = Math.max(totalAmount - paidAmount, 0);
  const isFullyPaid = totalAmount > 0 && remainingAmount === 0;

  return {
    ...record,
    project: record.project.trim(),
    personName: record.personName.trim(),
    material: record.material.trim(),
    quantity: record.quantity.trim(),
    totalAmount,
    paidAmount,
    remainingAmount,
    paidDate: isFullyPaid ? record.paidDate || todayInputDate() : "",
  };
};

export default function WorkManagement() {
  const [records, setRecords] = useStore(STORAGE_KEYS.WORK_RECORDS, []);
  const [form, setForm] = useState(initialRecord);
  const [editingIndex, setEditingIndex] = useState(null);

  const totals = useMemo(() => {
    const totalAmount = calculateTotal(records, "totalAmount");
    const paidAmount = calculateTotal(records, "paidAmount");
    const remainingAmount = Math.max(totalAmount - paidAmount, 0);

    return { totalAmount, paidAmount, remainingAmount };
  }, [records]);

  const hasRemainingAmount = records.some((record) => Number(record.remainingAmount || 0) > 0);
  const paidAmount = Math.min(Number(form.paidAmount || 0), Number(form.totalAmount || 0));
  const totalAmount = Number(form.totalAmount || 0);
  const formRemainingAmount = Math.max(totalAmount - paidAmount, 0);
  const isFormFullyPaid = totalAmount > 0 && formRemainingAmount === 0;

  const updateAmount = (field, value) => {
    const nextValue = Number(value || 0);

    setForm((current) => {
      const next = { ...current, [field]: value };
      const nextTotal = field === "totalAmount" ? nextValue : Number(current.totalAmount || 0);
      const nextPaid = field === "paidAmount" ? nextValue : Number(current.paidAmount || 0);

      if (nextTotal > 0 && nextPaid > nextTotal) {
        next.paidAmount = String(nextTotal);
      }

      const boundedPaid = Math.min(Number(next.paidAmount || 0), nextTotal);
      const nextRemaining = Math.max(nextTotal - boundedPaid, 0);
      const nextFullyPaid = nextTotal > 0 && nextRemaining === 0;

      next.paidDate = nextFullyPaid ? current.paidDate || todayInputDate() : "";

      return next;
    });
  };

  const saveRecord = (event) => {
    event.preventDefault();
    if (!form.project.trim() || !form.personName.trim() || !form.material.trim()) return;

    const record = normalizeRecord(form);

    if (editingIndex === null) {
      setRecords([...records, record]);
    } else {
      setRecords(records.map((item, index) => (index === editingIndex ? record : item)));
      setEditingIndex(null);
    }

    setForm({ ...initialRecord, date: todayInputDate() });
  };

  const editRecord = (index) => {
    const record = records[index];
    setForm({
      project: record.project || "",
      date: record.date || todayInputDate(),
      personName: record.personName || "",
      material: record.material || "",
      quantity: record.quantity || "",
      totalAmount: record.totalAmount || "",
      paidAmount: record.paidAmount || "",
      paidDate: record.paidDate || "",
    });
    setEditingIndex(index);
  };

  const deleteRecord = (index) => {
    setRecords(records.filter((_, currentIndex) => currentIndex !== index));

    if (editingIndex === index) {
      setForm({ ...initialRecord, date: todayInputDate() });
      setEditingIndex(null);
    }
  };

  const cancelEdit = () => {
    setForm({ ...initialRecord, date: todayInputDate() });
    setEditingIndex(null);
  };

  const tableColumns = [
    "project",
    "date",
    "personName",
    "material",
    "quantity",
    "totalAmount",
    "paidAmount",
    ...(hasRemainingAmount ? ["remainingAmount"] : []),
    "paidDate",
    "actions",
  ];

  const rows = records.map((record, index) => ({
    project: record.project,
    date: displayDate(record.date),
    personName: record.personName,
    material: record.material,
    quantity: record.quantity,
    totalAmount: formatCurrency(record.totalAmount),
    paidAmount: formatCurrency(record.paidAmount),
    remainingAmount:
      Number(record.remainingAmount || 0) > 0 ? formatCurrency(record.remainingAmount) : "Paid",
    paidDate: record.paidDate ? displayDate(record.paidDate) : "Not fully paid",
    actions: (
      <div className="table-actions">
        <button type="button" className="small-button" onClick={() => editRecord(index)}>
          Edit
        </button>
        <button type="button" className="small-button danger-button" onClick={() => deleteRecord(index)}>
          Delete
        </button>
      </div>
    ),
  }));

  return (
    <div className="page">
      <header className="page-header">
        <div>
          <p className="eyebrow">Work</p>
          <h1>Work Management</h1>
        </div>
      </header>

      <section className="stats-grid">
        <article className="card metric-card accent-card">
          <h3>Total Amount</h3>
          <strong>{formatCurrency(totals.totalAmount)}</strong>
          <p>{records.length} work records</p>
        </article>
        <article className="card metric-card success-card">
          <h3>Paid Amount</h3>
          <strong>{formatCurrency(totals.paidAmount)}</strong>
          <p>Collected or paid so far</p>
        </article>
        <article className="card metric-card warning-card">
          <h3>Remaining Amount</h3>
          <strong>{formatCurrency(totals.remainingAmount)}</strong>
          <p>{totals.remainingAmount === 0 ? "All records are fully paid" : "Amount still pending"}</p>
        </article>
      </section>

      <section className="work-section">
        <div className="section-heading">
          <div>
            <h2>Material Purchase Register</h2>
            <p>Enter the source details once. Amounts, balance, and completion date are calculated for you.</p>
          </div>
          <span className={isFormFullyPaid ? "status-pill paid" : "status-pill pending"}>
            {isFormFullyPaid ? "Fully paid" : `${formatCurrency(formRemainingAmount)} remaining`}
          </span>
        </div>

        <form className="form-panel work-register-form" onSubmit={saveRecord}>
          <label className="field">
            <span>Project</span>
            <input
              placeholder="Road repair contract"
              value={form.project}
              onChange={(event) => setForm({ ...form, project: event.target.value })}
            />
          </label>

          <label className="field">
            <span>Date</span>
            <input
              type="date"
              value={form.date}
              onChange={(event) => setForm({ ...form, date: event.target.value })}
            />
          </label>

          <label className="field">
            <span>Person Name</span>
            <input
              placeholder="Supplier or person name"
              value={form.personName}
              onChange={(event) => setForm({ ...form, personName: event.target.value })}
            />
          </label>

          <label className="field">
            <span>Material</span>
            <input
              placeholder="Cement, steel, paint"
              value={form.material}
              onChange={(event) => setForm({ ...form, material: event.target.value })}
            />
          </label>

          <label className="field">
            <span>Total Quantity</span>
            <input
              placeholder="50 bags"
              value={form.quantity}
              onChange={(event) => setForm({ ...form, quantity: event.target.value })}
            />
          </label>

          <label className="field">
            <span>Amount For Quantity</span>
            <input
              min="0"
              placeholder="25000"
              type="number"
              value={form.totalAmount}
              onChange={(event) => updateAmount("totalAmount", event.target.value)}
            />
          </label>

          <label className="field">
            <span>Paid Amount</span>
            <input
              min="0"
              max={form.totalAmount || undefined}
              placeholder="15000"
              type="number"
              value={form.paidAmount}
              onChange={(event) => updateAmount("paidAmount", event.target.value)}
            />
          </label>

          <label className="field calculated-field">
            <span>Remaining Amount</span>
            <input value={formatCurrency(formRemainingAmount)} readOnly />
          </label>

          <label className="field">
            <span>Complete Paid Date</span>
            <input
              disabled={!isFormFullyPaid}
              type="date"
              value={isFormFullyPaid ? form.paidDate : ""}
              onChange={(event) => setForm({ ...form, paidDate: event.target.value })}
            />
          </label>

          <div className="button-row">
            <button type="submit">{editingIndex === null ? "Save Record" : "Update Record"}</button>
            {editingIndex !== null && (
              <button type="button" className="secondary-button" onClick={cancelEdit}>
                Cancel
              </button>
            )}
          </div>
        </form>

        <Table columns={tableColumns} data={rows} emptyMessage="No work records have been added yet." />
      </section>
    </div>
  );
}
