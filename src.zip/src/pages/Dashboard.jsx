import { Link } from "react-router-dom";

export default function Dashboard() {
  return (
    <div className="page">
      <header className="page-header">
        <div>
          <p className="eyebrow">Overview</p>
          <h1>PWD Account Manager</h1>
        </div>
      </header>

      <div className="dashboard-grid">
        <Link to="/work" className="card">
          <span>Track</span>
          Work Management
        </Link>

        <Link to="/workers" className="card">
          <span>Manage</span>
          Workers Salary
        </Link>

        <Link to="/salary" className="card">
          <span>Review</span>
          Salary Report
        </Link>

        <Link to="/monthly" className="card">
          <span>Analyze</span>
          Monthly Report
        </Link>
      </div>
    </div>
  );
}
